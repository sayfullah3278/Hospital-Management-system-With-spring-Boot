package com.example.hospitalManagemente.controller;





import com.example.hospitalManagemente.model.Discharge;
import com.example.hospitalManagemente.service.DischargeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("")
public class DischargeController {

    @Autowired
    DischargeService dischargeService;


    @RequestMapping("/dispaspasent")
    public String dischargList(Model m){
        List<Discharge> dischargeList=dischargeService.getAlldispas();
        m.addAttribute("dischargeList",dischargeList);
        m.addAttribute("titel", "Discharg later");

        return "patient-dischargeform-list";
    }

    @RequestMapping("/dischargforms")
    public String dischargform(Model m){

        m.addAttribute("dischargform",new Discharge());
        m.addAttribute("title","DischargeForm");

        return "patient-dischargeform";
    }

    @PostMapping("/dischargls")
    public  String dischargSaveForm(@ModelAttribute Discharge dischargeList){
        dischargeService.savedischarge(dischargeList);
        return "redirect:/dispaspasent";
    }

    @RequestMapping("/dischargdelet/{bill_id}")
    public String dischargDelete(@PathVariable int dischargeId){
        dischargeService.deleteById(dischargeId);
        return "redirect:/dispaspasent";
    }

    @RequestMapping("/dischargeditfrm/{bill_id}")
    public String dischargEditFrm(@PathVariable int dischargeId,Model m){
        Discharge dischargeList=dischargeService.findBy(dischargeId);
        m.addAttribute("dischargform",dischargeList);
        return "patient-dischargeform";
    }


}
