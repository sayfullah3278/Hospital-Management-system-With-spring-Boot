package com.example.hospitalManagemente.restcontroller;


import com.example.hospitalManagemente.model.Admission;
import com.example.hospitalManagemente.repository.AdmissionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class AdmissionRestController {

    @Autowired
    AdmissionRepo admissionRepo;

    @GetMapping("/admission")
    public List<Admission> allAdmission() {
        return admissionRepo.findAll();
    }


    @PostMapping("/admission")
    public Admission saveAdmission(@RequestBody Admission admission) {

        return admissionRepo.save(admission);
    }


    @DeleteMapping("/admission/{admission_id}")
    public ResponseEntity<String> delete(@PathVariable("admission_id") int admission_id) {
        boolean exist = admissionRepo.existsById(admission_id);
        if (exist) {
            admissionRepo.deleteById(admission_id);
            return new ResponseEntity<>("Admission is delete", HttpStatus.OK);
        }
        return new ResponseEntity<>("Admission is not delete", HttpStatus.BAD_REQUEST);
    }



    @PutMapping("/admission/{admission_id}")
    public ResponseEntity<String> update(@PathVariable("admission_id") int admission_id, @RequestBody Admission admission){
        boolean exist=admissionRepo.existsById(admission_id);

        if(exist){
            Admission admission1=admissionRepo.getById(admission_id);
            admission1.setName(admission.getName());
            admission1.setAdmission_id(admission_id);
            admission1.setEmail(admission.getEmail()) ;
            admission1.setPhone(admission.getPhone());
            admission1.setAge(admission.getAge());
            admission1.setSex(admission.getSex());
            admission1.setBloodGroup(admission.getBloodGroup());
            admission1.setDepartment(admission.getDepartment());
            admission1.setDoctor(admission.getDoctor());
            admission1.setDiseaseDescription(admission.getDiseaseDescription());
            admission1.setAdmissionDate(admission.getAdmissionDate());
            admission1.setEmergencyContactNumber(admission.getEmergencyContactNumber());
            admission1.setRelationshipWithPatient(admission.getRelationshipWithPatient());
            admissionRepo.save(admission);
            return  new ResponseEntity<>("Admission is Updated", HttpStatus.OK);
        }
        return  new ResponseEntity<>("Admission is not Updated", HttpStatus.BAD_REQUEST);


    }
}