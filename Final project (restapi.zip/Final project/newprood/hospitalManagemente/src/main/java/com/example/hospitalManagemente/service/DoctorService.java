package com.example.hospitalManagemente.service;

import com.example.hospitalManagemente.model.Doctor;
import com.example.hospitalManagemente.repository.DoctorRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {


    @Autowired
    private DoctorRepo doctorRepo;

    public  void saveDoctor(Doctor doctor){
        doctorRepo.save(doctor);
    }

    public List<Doctor> getAllDoctor(){
        return  doctorRepo.findAll();
    }

    public void deleteById(int doctor_id){
        doctorRepo.deleteById(doctor_id);
    }

    public Doctor findBy(int doctor_id){
        return  doctorRepo.findById(doctor_id).get();
    }

//    public Doctor findBy(String name){ return doctorRepo.findByDoctor(name).get();}
}
