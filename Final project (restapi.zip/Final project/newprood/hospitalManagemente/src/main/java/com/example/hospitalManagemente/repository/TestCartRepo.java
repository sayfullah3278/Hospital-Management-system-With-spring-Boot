package com.example.hospitalManagemente.repository;

import com.example.hospitalManagemente.model.TestCart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public interface TestCartRepo extends JpaRepository<TestCart,Integer> {


}
