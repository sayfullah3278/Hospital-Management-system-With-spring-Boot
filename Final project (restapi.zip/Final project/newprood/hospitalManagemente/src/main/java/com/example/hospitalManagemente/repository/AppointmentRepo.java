package com.example.hospitalManagemente.repository;


import com.example.hospitalManagemente.model.Appointments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppointmentRepo extends JpaRepository<Appointments, Integer> {
    List<Appointments> findByDoctorNameIgnoreCase(String doctorName);
//
//    @Query("FROM Appointments a LEFT JOIN FETCH a.doctor_id WHERE a.appointment_id = :appointment_id")
//    Appointments findAppointmentWithDoctor(@Param("appointment_id") int appointment_id);
@Query("select app from Appointments app where app.doctorsId.doctor_id =?1")
    List<Appointments> findByDoc(int id);


}

