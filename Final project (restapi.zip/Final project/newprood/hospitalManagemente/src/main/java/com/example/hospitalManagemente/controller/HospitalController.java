package com.example.hospitalManagemente.controller;

import com.example.hospitalManagemente.model.Admission;
import com.example.hospitalManagemente.model.Bill;
import com.example.hospitalManagemente.model.Discharge;
import com.example.hospitalManagemente.repository.AdmissionRepo;
import com.example.hospitalManagemente.repository.BillRepository;
import com.example.hospitalManagemente.service.HospitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("")  // Set a base path for the controller
public class HospitalController {





    @Autowired
    private HospitalService hospitalService;


@RequestMapping("/billsvewe")
public String billList(Model m){
List<Bill>billslist=hospitalService.getAllbils();
m.addAttribute("billslist", billslist);
m.addAttribute("titel", "Bills");

return "billList";
}

@RequestMapping("/billforms")
public String billform(Model m){

    m.addAttribute("billform",new Bill());
    m.addAttribute("title","PasentBillForm");

    return "billform";
}

    @PostMapping("/billls")
    public  String billSaveForm(@ModelAttribute Bill bill, Model m){
        hospitalService.savebils(bill);
        return "redirect:/billsvewe";
    }

    @RequestMapping("/billdelet/{bill_id}")
    public String billDelete(@PathVariable int bill_id){
        hospitalService.deleteById(bill_id);
        return "redirect:/billsvewe";
    }

    @RequestMapping("/billeditfrm/{bill_id}")
    public String billEditFrm(@PathVariable int bill_id,Model m){
        Bill bill=hospitalService.findBy(bill_id);
        m.addAttribute("billform",bill);
        return "billform";
    }


}




