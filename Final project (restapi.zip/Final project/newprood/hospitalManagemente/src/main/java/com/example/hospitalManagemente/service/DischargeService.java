package com.example.hospitalManagemente.service;



import com.example.hospitalManagemente.model.Discharge;
import com.example.hospitalManagemente.repository.DischargeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DischargeService {

    @Autowired
    private DischargeRepository dischargeRepository;

    public  void savedischarge(Discharge discharge){
        dischargeRepository.save(discharge);
    }

    public List<Discharge> getAlldispas(){
        return  dischargeRepository.findAll();
    }

    public void deleteById(int dischargeId){
        dischargeRepository.deleteById(dischargeId);
    }

    public Discharge findBy(int dischargeId){
        return  dischargeRepository.findById(dischargeId).get();
    }
}

