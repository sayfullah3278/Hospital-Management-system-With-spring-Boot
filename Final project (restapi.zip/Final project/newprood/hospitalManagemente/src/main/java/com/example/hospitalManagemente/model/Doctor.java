package com.example.hospitalManagemente.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int doctor_id;


    private  String doctorName;



    private  String phone;


    private  String department;


    private  String specilization;


    private  String qualification;

    private  String experience;



    private String date;


    @OneToMany(mappedBy = "doctorName")  // mappedBy refers to the field in the Appointments entity
    private List<Appointments> appointments;

}
