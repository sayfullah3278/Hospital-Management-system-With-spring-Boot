CREATE DATABASE  IF NOT EXISTS `security55hospitalmanagement` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `security55hospitalmanagement`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: security55hospitalmanagement
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admission`
--

DROP TABLE IF EXISTS `admission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admission` (
  `admission_id` int NOT NULL AUTO_INCREMENT,
  `admission_date` datetime(6) DEFAULT NULL,
  `age` int NOT NULL,
  `blood_group` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `disease_description` varchar(255) DEFAULT NULL,
  `doctor` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `emergency_contact_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `relationship_with_patient` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `doctor_id` int DEFAULT NULL,
  PRIMARY KEY (`admission_id`),
  KEY `FKqi7hetb5f8mblyma0kd4b6j4b` (`doctor_id`),
  CONSTRAINT `FKqi7hetb5f8mblyma0kd4b6j4b` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admission`
--

LOCK TABLES `admission` WRITE;
/*!40000 ALTER TABLE `admission` DISABLE KEYS */;
INSERT INTO `admission` VALUES (1,'2024-01-21 09:29:00.000000',32,'B+','Cardiology','aasdasaas',NULL,'sayfullah3278@gmail.com','12312312312','salman','02154874568','brother','male',6);
/*!40000 ALTER TABLE `admission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `appointment_id` int NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `disise` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `doctor_id` int DEFAULT NULL,
  `doctor_name` varchar(255) DEFAULT NULL,
  `patient_id` int DEFAULT NULL,
  `doctor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`appointment_id`),
  KEY `FKgpgce3qtc5fajyl4j5srcjkcf` (`doctor_id`),
  KEY `FKcl9b1a19a01yhjcdibna1gjl` (`patient_id`),
  CONSTRAINT `FKcl9b1a19a01yhjcdibna1gjl` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FKgpgce3qtc5fajyl4j5srcjkcf` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (2,'2024-01-21T13:24','Cardiology','adsdsadas','sayfullah3278@gmail.com','asdasasd','54643456354',6,NULL,NULL,NULL),(3,'2024-01-21T13:24','Cardiology','adsdsadas','sayfullah3278@gmail.com','asdasasd','54643456354',7,NULL,NULL,NULL),(4,'2024-01-19T09:39','ORTHOPEDICS','fsddsfsdf','sayfullah3278@gmail.com','Dr. kadr','02154874568',3,NULL,NULL,NULL),(5,'2024-01-19T13:46','Cardiology','dsfsfsdfsd','sayfullah3278@gmail.com','Foysal ','5324564',4,NULL,NULL,NULL),(6,'2024-01-25T19:25','ORTHOPEDICS','fgfdgfdgdgdf','hdfgdg3278@gmail.com','asdasasd','02154874568',7,NULL,NULL,NULL),(7,'2024-01-11T15:43','Dermatology & Venereology','fsdfsdf','hdfgdg3278@gmail.com','fsdsdf','02154874568',5,NULL,NULL,NULL),(8,'2024-01-10T13:46',NULL,'fdsfsdf','hdfgdg3278@gmail.com','Shohab Sikder','54643456354',NULL,NULL,NULL,NULL),(9,'2024-01-11T11:51',NULL,'zcvvcbcv','sayfullah3278@gmail.com','kfl','5324564',3,NULL,NULL,NULL);
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill` (
  `bill_id` int NOT NULL AUTO_INCREMENT,
  `age` varchar(255) DEFAULT NULL,
  `due_amount` double NOT NULL,
  `paid_amount` double NOT NULL,
  `total_amount` double NOT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `admition_date` varchar(255) DEFAULT NULL,
  `discharg_date` varchar(255) DEFAULT NULL,
  `admitedDays` double DEFAULT NULL,
  `passent_name` varchar(255) DEFAULT NULL,
  `admited_days` double NOT NULL,
  `daily_cost` double NOT NULL,
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES (1,'22',10000,25000,35000,'Cash','2024-01-17T16:19','2024-01-21T17:19',NULL,'jakaria',5,7000),(2,'22',10000,25000,35000,'Cash','2024-01-17T16:19','2024-01-21T17:19',NULL,'jakaria',5,7000);
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discharge`
--

DROP TABLE IF EXISTS `discharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discharge` (
  `discharge_id` int NOT NULL AUTO_INCREMENT,
  `admission_date` date DEFAULT NULL,
  `age` int DEFAULT NULL,
  `discharge_date` varchar(255) DEFAULT NULL,
  `discharge_summary` varchar(1000) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `admission_id` int DEFAULT NULL,
  `admissiondate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`discharge_id`),
  KEY `FK5ojpyrcrsvieipj42af0chif` (`admission_id`),
  CONSTRAINT `FK5ojpyrcrsvieipj42af0chif` FOREIGN KEY (`admission_id`) REFERENCES `admission` (`admission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discharge`
--

LOCK TABLES `discharge` WRITE;
/*!40000 ALTER TABLE `discharge` DISABLE KEYS */;
INSERT INTO `discharge` VALUES (1,NULL,22,'2024-01-21T15:41','adasdasda','Shohab Sikder',NULL,'2024-01-17T14:40');
/*!40000 ALTER TABLE `discharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor` (
  `doctor_id` int NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `experience` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `qualification` varchar(255) DEFAULT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `doctor_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (2,'2024-01-20','NUCLEAR MEDICINE','8Yer','02154874568','MBBS,FCPS,FRCPS,Consaltent','NUCLEAR MEDICINE','Dr Sen',NULL),(3,'2024-01-31','NUCLEAR MEDICINE','12Yer','02154874568','MBBS,FCPS,FRCPS,Consaltent','NUCLEAR MEDICINE','Dr P K Roy',NULL),(4,'2024-01-17T11:45','Cardiology','8Yer','02154874568','MBBS,FCPS,FRCPS,Consaltent','Cardiology','Dr. Kawser Hosain',NULL),(5,'2022-06-16T09:45','PAEDIATRIC NEUROLOGY','18Yer','0124593','MBBS,FCPS,FRCPS','PAEDIATRIC NEUROLOGY','Dr.  Hosain',NULL),(6,'2024-01-20T13:08','HEPATOBILIARY AND PANCREATIC SURGERY','10Yer','02154874568','MBBS,FCPS,FRCPS,Consaltent','HEPATOBILIARY AND PANCREATIC SURGERY','Dr.  Agad  Ahmed',NULL),(7,'2024-01-20T13:08','NUCLEAR MEDICINE','10Yer','02154874568','MBBS,FCPS,FRCPS,Consaltent','NUCLEAR MEDICINE','Dr.  Alauddin Khan',NULL),(8,'2024-01-21T13:12','Accident & Emergency','10Yer','6847654','MBBS,FCPS,FRCPS,Consaltent','Accident & Emergency','Dr.  Hosnaara Begum',NULL),(9,'2024-01-17T09:44','ORTHOPEDICS','15yer','44222432432','MBBS,FCPS,FRCPS,Sargen','Cardiology','Dr. Abulkalam Agad ',NULL);
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `employee_id` int NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `id` int NOT NULL AUTO_INCREMENT,
  `age` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `doctor_name` int DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `doctor_id` int DEFAULT NULL,
  `appointments_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4cy0sxpqsp65fn8cpliw5jnoq` (`doctor_name`),
  KEY `FK2kvkofukyf6lcmhr88s7tmrj4` (`doctor_id`),
  KEY `FKf9t27e16blcuqm6by17ifv6l8` (`appointments_id`),
  CONSTRAINT `FK2kvkofukyf6lcmhr88s7tmrj4` FOREIGN KEY (`doctor_id`) REFERENCES `appointments` (`appointment_id`),
  CONSTRAINT `FK4cy0sxpqsp65fn8cpliw5jnoq` FOREIGN KEY (`doctor_name`) REFERENCES `doctor` (`doctor_id`),
  CONSTRAINT `FKf9t27e16blcuqm6by17ifv6l8` FOREIGN KEY (`appointments_id`) REFERENCES `appointments` (`appointment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testcart`
--

DROP TABLE IF EXISTS `testcart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `testcart` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `price` double NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testcart`
--

LOCK TABLES `testcart` WRITE;
/*!40000 ALTER TABLE `testcart` DISABLE KEYS */;
INSERT INTO `testcart` VALUES (1,1200,'CBC'),(2,1000,'x-Ray');
/*!40000 ALTER TABLE `testcart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `date` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `doctor` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-24 12:49:55
