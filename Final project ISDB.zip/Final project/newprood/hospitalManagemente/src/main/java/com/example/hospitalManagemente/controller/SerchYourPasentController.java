package com.example.hospitalManagemente.controller;

import com.example.hospitalManagemente.model.Appointments;
import com.example.hospitalManagemente.model.Doctor;
import com.example.hospitalManagemente.model.Patient;
import com.example.hospitalManagemente.repository.AppointmentRepo;
import com.example.hospitalManagemente.repository.DoctorRepo;
import com.example.hospitalManagemente.repository.PassentSarchRepo;
import com.example.hospitalManagemente.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class SerchYourPasentController {

    @Autowired
    private AppointmentRepo appointmentsRepository;

    @Autowired
    private DoctorRepo doctorRepository;

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private PassentSarchRepo passentSarchRepo;

    @GetMapping("/searchPatientsByDoctor")
    public String searchPatientsByDoctor(Model model) {
        List<Doctor> doctors = doctorRepository.findAll();
        model.addAttribute("doctors", doctors);
        return "pasentfindbydoctorname";
    }

//    @PostMapping("/searchPatients")
//    public String searchPatientsByDoctor(@RequestParam String doctorName, Model model) {
//        try {
//            doctorName = doctorName.trim();
//            System.out.println("Doctor Name (Trimmed): " + doctorName);
//            List<Appointments> appointments = appointmentsRepository.findByDoctorNameIgnoreCase(doctorName);
//            System.out.println("Number of Appointments: " + appointments.size());
//            model.addAttribute("appointments", appointments);
//            List<Doctor> doctors = doctorRepository.findAll();
//            model.addAttribute("doctors", doctors);
//
//        } catch (Exception e) {
//            // Handle exception (e.g., log error, display user-friendly message)
//            e.printStackTrace();
//            model.addAttribute("error", "An error occurred during the search.");
//        }
//        return "pasentfindbydoctornamelist";
//    }

    @GetMapping("/searchPatients")
    public String searchPatientsByDoctor(@RequestParam("doctorName") int id, Model model) {
        try {



            List<Appointments> appList = appointmentsRepository.findByDoc(id);
            model.addAttribute("appList", appList);
        } catch (Exception e) {
            // Handle exception (e.g., log error, display user-friendly message)
            e.printStackTrace();
            model.addAttribute("error", "An error occurred during the search.");
        }
        return "pasentfindbydoctornamelist";
    }



//    @GetMapping("/passlist")
//    public String callpassent(Model m){
//        List<Patient> patients=passentSarchRepo.findAll();
//        m.addAttribute("patients",patients);
//        m.addAttribute("titel","All pasents");
//        return "pasentfindbydoctornamelist";
//    }


//    @PostMapping("/doctorform")
//    public String doctorsSaveForm(@ModelAttribute Patient patient){
//        passentSarchRepo.findAll(patient);
//        return "redirect:/passlist";
//
//
//    }

//    @GetMapping("/searchPatients")
//    public String searchPatients(@RequestParam("doctorName") String doctorName, Model model) {
//        // Fetch appointments by doctor
//        List<Appointments> appointments = appointmentService.getAppointmentsByDoctorName(doctorName);
//
//        // Extract patient information from appointments
//        List<Patient> patients = appointments.stream()
//                .map(Appointments::getPatient)
//                .collect(Collectors.toList());
//
//        model.addAttribute("patients", patients);
//        return "pasentfindbydoctornamelist"; // Replace with the actual view name
//    }


    @RequestMapping("/patientsByDoctor")
    public ResponseEntity<List<Patient>> findPatientsByDoctorName
            (Model m,@RequestParam String name) {
        List<Patient> patients =
                appointmentService.findPatientsByDoctorName(name);
        m.addAttribute("pasentList",patients);
        m.addAttribute("titel","Patients By Doctor");

//        return "pasentfindbydoctorname";
        return ResponseEntity.ok(patients);
    }
    @RequestMapping("/add")
    public String showAppointmentForm(Model model) {
        model.addAttribute("appointment", new Appointments());
        model.addAttribute("doctors", doctorRepository.findAll());
        return "add-appointment";
    }

}
