package com.example.hospitalManagemente.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor


public class Discharge {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int dischargeId;



    private String name;


    private int age;


    private String admissiondate;



    private String dischargeDate;


    private String dischargeSummary;

//
//    @ManyToOne
//    @JoinColumn(name = "admission_id")
//    private Admission admission;

}
