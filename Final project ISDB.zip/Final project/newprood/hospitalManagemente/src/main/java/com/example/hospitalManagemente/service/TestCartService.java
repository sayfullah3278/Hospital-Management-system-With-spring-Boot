package com.example.hospitalManagemente.service;

import com.example.hospitalManagemente.model.TestCart;
import com.example.hospitalManagemente.repository.TestCartRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestCartService {

    @Autowired
    public   TestCartRepo testCartRepo;

    public  void saveTest(TestCart testCart){
        testCartRepo.save(testCart);
    }

    public List<TestCart> getAllTest(){
        return  testCartRepo.findAll();
    }

    public void deleteById(int product_id){
        testCartRepo.deleteById(product_id);
    }

    public TestCart findBy(int product_id){
        return   testCartRepo.findById(product_id).get();
    }
}