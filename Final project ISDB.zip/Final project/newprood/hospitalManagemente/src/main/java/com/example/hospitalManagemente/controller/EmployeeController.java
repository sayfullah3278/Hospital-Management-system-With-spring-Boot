package com.example.hospitalManagemente.controller;



import com.example.hospitalManagemente.model.Employee;

import com.example.hospitalManagemente.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("")
public class EmployeeController {


    @Autowired
    EmployeeService employeeService;

    @RequestMapping("/employeelist")
    public String addEmployee(Model m){
        List<Employee> employeeList=employeeService.getAllEmployee();
        m.addAttribute("employeeList",employeeList);
        m.addAttribute("titel","All Doctors");
        return "employeelist";
    }

    @RequestMapping("/employeeform")
    public String addEmployeefrm(Model m){
//
        m.addAttribute("employeSave",new Employee());
        m.addAttribute("title","Employee List");
        return "employee";
    }

    @PostMapping("/employeessform")
    public String EmployeeSaveForm(@ModelAttribute Employee employeeSave){
        employeeService.saveEmployee(employeeSave);
        return "redirect:/employeelist";


    }



    @RequestMapping("/employeedelete/{employee_id}")
    public String  EmployeeDelete (@PathVariable int employee_id){
        employeeService.deleteById(employee_id);
        return "redirect:/employeelist";
    }

    @RequestMapping("/editemployee/{employee_id}")
    public String EmployeeEditForm(@PathVariable int employee_id,Model m){
        Employee  employeelist= employeeService.findBy(employee_id);
        m.addAttribute("employeSave",employeelist);
        return "employee";
    }

}
