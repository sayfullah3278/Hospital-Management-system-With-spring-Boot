package com.example.hospitalManagemente.controller;


import com.example.hospitalManagemente.model.TestCart;
import com.example.hospitalManagemente.service.TestCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/testCart")
public class TestCartController {

    @Autowired
    private TestCartService testCartService;



    // Mapping to display all tests in the cart
    @GetMapping("/all")
    public String showAllTests(Model model) {
        List<TestCart> testList = testCartService.getAllTest();
        model.addAttribute("testList", testList);
        model.addAttribute("testCart", new TestCart());
        return "showcart";
    }

    @GetMapping("/cartform")
    public String showAllTestss(Model model) {
        List<TestCart> testList = testCartService.getAllTest();
        model.addAttribute("testList", testList);
        model.addAttribute("testCart", new TestCart());
        return "testItmsaddtocart";
    }

    // Mapping to add a test to the cart
    @PostMapping("/addtocart")
    public String addTestToCart(@ModelAttribute("testCart") TestCart testCart) {
        testCartService.saveTest(testCart);
        return "redirect:/testCart/cartform";
    }

    // Mapping to delete a test from the cart by testId
    @GetMapping("/delete/{testId}")
    public String deleteTest(@PathVariable("testId") int testId) {
        testCartService.deleteById(testId);
        return "redirect:/testCart/all";
    }

    // Mapping to view details of a specific test by testId
    @GetMapping("/details/{testId}")
    public String viewTestDetails(@PathVariable("testId") int testId, Model model) {
        TestCart testCart = testCartService.findBy(testId);
        model.addAttribute("testCart", testCart);
        return "testCart/testDetails";
    }
}
