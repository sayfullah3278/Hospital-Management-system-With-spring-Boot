package com.example.hospitalManagemente.service;

import com.example.hospitalManagemente.model.Bill;
import com.example.hospitalManagemente.model.Patient;
import com.example.hospitalManagemente.repository.BillRepository;
import com.example.hospitalManagemente.repository.PassentSarchRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class PassentGetService {


    @Autowired
    private PassentSarchRepo passentSarchRepo;

    public  void savepass(Patient patient){
        passentSarchRepo.save(patient);
    }

    public List<Patient> getAllpass(){
        return  passentSarchRepo.findAll();
    }

    public void deleteById(int id){
        passentSarchRepo.deleteById(id);
    }

    public Patient findBy(int id){
//        return  passentSarchRepo.findById(id).get();
        return passentSarchRepo.findById(id).orElse(null);
    }
}
